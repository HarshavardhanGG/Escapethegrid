const gridSize = 5;
let movesLeft = 10;
let robotPosition = { x: 0, y: 0 };
let grid = [];

// Generate random grid
function generateGrid() {
  grid = Array.from({ length: gridSize }, () =>
    Array.from({ length: gridSize }, () => {
      const rand = Math.random();
      if (rand < 0.1) return "T"; // 10% chance of trap
      if (rand < 0.2) return "P"; // 10% chance of power-up
      return ""; // Empty space
    })
  );
  grid[0][0] = "R"; // Starting position
  grid[gridSize - 1][gridSize - 1] = "E"; // Exit
}

// Render grid
function renderGrid() {
  const board = document.getElementById("game-board");
  board.innerHTML = "";
  grid.forEach((row, y) => {
    row.forEach((cell, x) => {
      const div = document.createElement("div");
      div.classList.add("cell");
      if (cell === "R") div.classList.add("robot");
      if (cell === "T") div.classList.add("trap");
      if (cell === "P") div.classList.add("power-up");
      if (cell === "E") div.classList.add("exit");
      div.textContent = cell;
      board.appendChild(div);
    });
  });
}

// Move robot
function moveRobot(dx, dy) {
  const newX = robotPosition.x + dx;
  const newY = robotPosition.y + dy;

  if (newX < 0 || newY < 0 || newX >= gridSize || newY >= gridSize) return;

  const targetCell = grid[newY][newX];
  if (targetCell === "T") {
    document.getElementById("status").textContent = "You hit a trap!";
    return;
  }

  if (targetCell === "P") {
    movesLeft += 3; // Power-up adds moves
  }

  if (targetCell === "E") {
    document.getElementById("status").textContent = "You win!";
    return;
  }

  grid[robotPosition.y][robotPosition.x] = "";
  robotPosition = { x: newX, y: newY };
  grid[newY][newX] = "R";

  movesLeft--;
  document.getElementById("moves").textContent = movesLeft;

  if (movesLeft <= 0) {
    document.getElementById("status").textContent = "Game Over!";
    return;
  }

  renderGrid();
}

// Initialize game
function startGame() {
  robotPosition = { x: 0, y: 0 };
  movesLeft = 10;
  generateGrid();
  renderGrid();
  document.getElementById("status").textContent = "";
  document.getElementById("moves").textContent = movesLeft;
}

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowUp") moveRobot(0, -1);
  if (e.key === "ArrowDown") moveRobot(0, 1);
  if (e.key === "ArrowLeft") moveRobot(-1, 0);
  if (e.key === "ArrowRight") moveRobot(1, 0);
});

startGame();
